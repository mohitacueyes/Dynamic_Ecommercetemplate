import Register from "./Register";
export {
    Register
}