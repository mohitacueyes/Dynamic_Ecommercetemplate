import ProductDetails from "./ProductDetails";
export{
    ProductDetails
}