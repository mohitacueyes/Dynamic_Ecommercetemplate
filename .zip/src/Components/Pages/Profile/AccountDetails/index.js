import AccountDetails from "./AccountDetails";
export{
    AccountDetails
}