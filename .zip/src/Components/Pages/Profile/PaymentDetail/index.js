import PaymentDetail from "./PaymentDetail";
export{
    PaymentDetail
}