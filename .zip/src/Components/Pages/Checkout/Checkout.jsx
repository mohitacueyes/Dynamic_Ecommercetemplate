import React from 'react'
import Checkoutdetails from './Details/Checkoutdetails'


function Checkout() {
  return (
    <>
       <Checkoutdetails />
    </>
  )
}

export default Checkout