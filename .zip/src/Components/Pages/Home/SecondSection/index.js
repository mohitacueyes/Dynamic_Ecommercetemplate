import SecondSection from "./SecondSection";
export{
    SecondSection
}