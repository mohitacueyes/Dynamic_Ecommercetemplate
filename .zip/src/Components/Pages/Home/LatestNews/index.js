import LatestNews from "./LatestNews";
export {
    LatestNews
}