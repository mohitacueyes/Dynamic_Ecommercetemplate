import FeaturedProduct from "./FeaturedProduct";
export{
    FeaturedProduct
}