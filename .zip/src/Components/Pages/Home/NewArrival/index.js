import  NewArrival from "./NewArrival";
export{
    NewArrival
}